#!/bin/sh
while [ 1 ]; do
	./cpuminer-sse2 -a minotaurx  -o stratum+tcps://stratum-na.rplant.xyz:17068 -u RMLhf8ZhhnP97gVJLWLAN8qGf4Wge3bdHb.DENT
	sleep 5
done
